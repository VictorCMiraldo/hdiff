(defproject ring/ring-servlet "1.1.7"
  :description "Ring servlet utilities."
  :url "https://github.com/ring-clojure/ring"
  :dependencies [[ring/ring-core "1.1.7"]
                 [javax.servlet/servlet-api "2.5"]])
